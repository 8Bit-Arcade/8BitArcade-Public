<?php

/*
 * Here is the Payment module routes.
 */

(new \App\PayModule\Module())->module_routes();